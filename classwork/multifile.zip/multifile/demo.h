// demo.h
#ifndef DEMO_H
#define DEMO_H

int SUM(int a, int b);
int SUB(int a, int b);
int MUL(int a, int b);
int DIV(int a, int b);

#endif
