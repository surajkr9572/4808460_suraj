// sum.c
#include "demo.h"

int SUM(int a, int b) {
    return a + b;
}
