// sub.c
#include "demo.h"

int SUB(int a, int b) {
    return a - b;
}
