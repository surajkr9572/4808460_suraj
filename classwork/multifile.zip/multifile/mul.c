// mul.c
#include "demo.h"

int MUL(int a, int b) {
    return a * b;
}
